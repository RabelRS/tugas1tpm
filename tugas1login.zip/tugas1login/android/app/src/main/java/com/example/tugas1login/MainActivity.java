package com.example.tugas1login;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
